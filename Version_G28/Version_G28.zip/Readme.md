Software Implementation of PLC with STM32 "bluepill" hardware.</br></br>
Version G28 -</br>
For this release you can use register range up to D2048.</br>
Solved some problem with modbus RTU master - now UART1 and UART2 can use master mode independently  and simultaneously.</br>
