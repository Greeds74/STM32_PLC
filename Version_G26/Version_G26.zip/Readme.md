Software Implementation of PLC with STM32 "bluepill" hardware.</br>
Version G26</br>
Solved some problems with modbus RTU master.</br>
Added version  without support bootloader.</br>
