# STM32_PLC
Software Implementation of PLC with STM32 "bluepill" hardware.</br></br>
From version G25</br>
Added simple PID algoritm implementation.</br>
Added support for PWM operation.</br>
Please, use configuration software with version more than or equal 465.</br>
