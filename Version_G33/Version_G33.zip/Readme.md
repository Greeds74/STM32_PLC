Software Implementation of PLC with STM32 "bluepill" hardware.</br></br>
Version G33 -</br>
Extended number of output - now available for use output with address Y10,Y11,Y12 and Y13. </br>
Description you can find in the pdf docs.</br>
In this release PWM channel number extended to 9 channel.</br>

Version G31 -</br>
Fixed problem with uploading register area from device - now limit is D2047.</br>
Increased stability .</br>
Fixed some text in the configuration utility.</br>
