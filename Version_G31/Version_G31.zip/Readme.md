Software Implementation of PLC with STM32 "bluepill" hardware.</br></br>
Version G31 -</br>
Fixed problem with uploading register area from device - now limit is D2047.</br>
Increased stability .</br>
Fixed some text in the configuration utility.</br>
