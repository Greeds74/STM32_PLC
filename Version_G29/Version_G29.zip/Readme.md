Software Implementation of PLC with STM32 "bluepill" hardware.</br></br>
Version G29 -</br>
For this release, the register from D0 to D9 is now power independent - supported from the 3V backup battery.</br>
Solved problem with UART2 DE pin.</br>
